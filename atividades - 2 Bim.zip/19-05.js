//Atividade 01
let inputlargura = document.querySelector("#largura");
let inputcomprimento = document.querySelector("#comprimento");
let btTerreno = document.querySelector("#btTerreno");
let Tamanho = document.querySelector("#Tamanho");

btTerreno.onclick = function (){
    //retornando os valores dos inputs em números
    let largura = Number(inputlargura.value);
    let comprimento = Number(inputcomprimento.value);

    //Calculando a área do terreno
    let area = largura * comprimento;

    Tamanho.innerHTML = `A área total do terreno equivale à ${area.toFixed(2)} m²`;
}

//Atividade 02
let inputcavalos = document.querySelector("#cavalos");
let btFerraduras = document.querySelector("#btFerraduras");
let TotaldeF = document.querySelector("#TotaldeF");

btFerraduras.onclick = function (){
    let cavalos = Number(inputcavalos.value);

    let FCavalos = cavalos * 4;

    TotaldeF.textContent = `A quantidade total de Ferraduras necessárias será ${FCavalos}`;
}

//Atividade 03
let inputpao = document.querySelector("#pao");
let inputbroa = document.querySelector("#broa");
let btCaixa = document.querySelector("#btCaixa");
let texto = document.querySelector("#texto");

btCaixa.onclick = function (){
    let pao = Number(inputpao.value);
    let broa = Number(inputbroa.value);

    let TotalPao = pao * 0.12;
    let TotalBroa = broa * 1.5;
    let TotalJuntos = TotalPao + TotalBroa;

    let Poupanca = TotalJuntos * 0.10;

    texto.innerHTML = `
    Total com Pães: R$ ${TotalPao.toFixed(2)} <br>
    Total com Broas: R$ ${TotalBroa.toFixed(2)} <br>
    <strong>Total do Dia: R$ ${TotalJuntos.toFixed(2)} </strong> <br>
    Valor a guardar na Poupança (10%): <strong> R$ ${Poupanca.toFixed(2)}</strong>`;
}

//Atividade 04
let inputnome = document.querySelector("#nome");
let inputidade = document.querySelector("#idade");
let btGerar = document.querySelector("#btGerar");
let TempoVivido = document.querySelector("#TempoVivido");

btGerar.onclick = function (){
    let nome = inputnome.value;
    let idade = Number(inputidade.value);

    let dias = idade * 365;
    let horas = dias * 24;
    let minutos = horas * 60;
    let segundos = minutos * 60;
    
    TempoVivido.innerHTML = `
    ${nome.toUpperCase()}, <br>
    você já viveu ${dias} dias, <br>
    ${horas} horas, <br>
    ${minutos} minutos e <br>
    ${segundos} segundos.`;
}
// .toUpperCase() - para colocar texto

//Atividade 05
let inputReaisGasolina = document.querySelector("#ReaisGasolina");
let btLitros = document.querySelector("#btLitros");
let APagar = document.querySelector("#APagar");

btLitros.onclick = function (){
    let ReaisGasolina = Number(inputReaisGasolina.value);
    let precoLitro = 6.29;

    let litros = ReaisGasolina / precoLitro;

    APagar.innerHTML = `
    Valor Total Pago: R$ ${ReaisGasolina.toFixed(2)} <br>
    Quantidade de Litros: ${litros.toFixed(2)} L <br>
    Preço do Litro da Gasolina Comum: ${precoLitro.toFixed(2)} <br>
    <small> (última atualização em 20/05/2025) </small>`;
}

//Atividade 06
let inputRefeicao = document.querySelector("#Refeicao");
let btPrecoQuilo = document.querySelector("#btPrecoQuilo");
let TotalQuilo = document.querySelector("#TotalQuilo");

btPrecoQuilo.onclick = function (){
    let Refeicao = Number(inputRefeicao.value);
    let PorQuilo = 12.00;
    let Prato = 800; //em gramas

    let PesoLiquido = Refeicao - Prato; //em gramas
    let PesoKg = PesoLiquido / 1000; // converte para quilos
    let Preco = PesoKg * PorQuilo; 

    TotalQuilo.innerHTML = `
    Peso Total da Refeição (sem o prato): ${PesoKg.toFixed(2)} Kg <br>
    Valor a pagar pela Refeição: ${Preco.toFixed(2)}`;
}

//Atividade 07
let inputdia = document.querySelector("#dia");
let inputmes = document.querySelector("#mes");
let btInformar = document.querySelector("#btInformar");
let sepassaram = document.querySelector("#sepassaram");

btInformar.onclick = function (){
    let dia = Number (inputdia.value);
    let mes = Number (inputmes.value);

    //Considerando que cada mês tem 30 dias
    let diasPassados = (mes - 1) * 30 + dia;
   
    sepassaram.textContent = `Desde o inicío do ano até ${dia}/${mes}, se passaram ${diasPassados} dias.`;
}

//Atividade 08
let inputpequeno = document.querySelector("#pequeno");
let inputmedio = document.querySelector("#medio");
let inputgrande = document.querySelector("#grande");
let btArrecadado = document.querySelector("#btArrecadado");
let ValorArrecadado = document.querySelector("#ValorArrecadado");

btArrecadado.onclick = function (){
    let pequeno = Number (inputpequeno.value);
    let medio = Number (inputmedio.value);
    let grande = Number (inputgrande.value);

    let Ppreco = 10;
    let Mpreco = 12;
    let Gpreco = 15;

    let ValorPequeno = pequeno * Ppreco;
    let ValorMedio = medio * Mpreco;
    let ValorGrande = grande * Gpreco;
    let Somatoria = ValorPequeno + ValorMedio + ValorGrande;

    ValorArrecadado.innerHTML = `
    Camisetas Pequenas: R$ ${ValorPequeno.toFixed(2)} <br>
    Camisetas Médias: R$ ${ValorMedio.toFixed(2)} <br>
    Camisetas Grandes: R$ ${ValorGrande.toFixed(2)} <br>
    <strong> Valor Total Arrecadado: R$ ${Somatoria.toFixed(2)} </strong>
    `;
}

//Atividade 09
let inputParX = document.querySelector("#ParX");
let inputParY = document.querySelector("#ParY");
let btDistancia = document.querySelector("#btDistancia");
let DistanciaPar = document.querySelector("#DistanciaPar");

btDistancia.onclick = function () {
    let X = Number (inputParX.value);
    let Y = Number (inputParY.value);

    let distancia = Math.abs (X - Y) //Distância absoluta entre pontos

    DistanciaPar.textContent = `A distância entre os pontos é de ${distancia}`;
}

//Atividade 10
let inputtempo = document.querySelector("#tempo");
let inputdias = document.querySelector("#dias");
let btControl = document.querySelector("#btControl");
let relatorio = document.querySelector("#relatorio");

btControl.onclick = function (){
    let tempo = Number(inputtempo.value);
    let dias = Number (inputdias.value);

    let trabalho = (tempo - 1) * 30 + dias;

    relatorio.textContent = `Na Fábrica, estamos há ${trabalho} dias sem acidentes.`;
}

//Atividade 11
let inputsalarioBase = document.querySelector("#salarioBase");
let btRealidade = document.querySelector("#btRealidade");
let holerite = document.querySelector("#holerite");

btRealidade.onclick = function (){
    let base = Number (inputsalarioBase.value);
    
    let aumento = base * 0.15;  // Aumento de 15%
    let salarioComAumento = base + aumento;
    let imposto = salarioComAumento * 0.08; // Desconto de 8%
    let salarioFinal = salarioComAumento - imposto;

    holerite.innerHTML = `
    <strong>Holerite:</strong><br>
    Salário Base: R$ ${base.toFixed(2)} <br>
    Aumento (15%): R$ ${aumento.toFixed(2)} <br>
    Salário com Aumento: R$ ${salarioComAumento.toFixed(2)} <br>
    Desconto de Imposto (8%): R$ ${imposto.toFixed(2)} <br>
    <strong>Salário Final: R$ ${salarioFinal.toFixed(2)}</strong>`;
}

//Atividade 12
let inputNumero = document.querySelector("#numero");
let btSeparar = document.querySelector("#btSeparar");
let result = document.querySelector("#result");

btSeparar.onclick = function () {
    let numero = Number(inputNumero.value);

    let centena = 0;
    let dezena = 0;
    let unidade = 0;

    if (numero >= 0 && numero <= 999) {
        centena = Math.floor(numero / 100);
        dezena = Math.floor((numero % 100) / 10);
        unidade = numero % 10;

        result.innerHTML = `
            CENTENA = ${centena} <br>
            DEZENA = ${dezena} <br>
            UNIDADE = ${unidade}`;
    } else {
        result.innerHTML = "⚠️ Digite um número entre 0 e 999.";
    }
}

//Atividade 13
let inputdiametro = document.querySelector("#diametro");
let btRaio = document.querySelector("#btRaio");
let resposta = document.querySelector("#resposta");

btRaio.onclick = function (){
 let diametro = Number(inputdiametro.value)   ;

 let raio = diametro / 2;
 let area = 2 * 3.14 * raio;

 resposta.innerHTML = `A área toral da pizza é ${area.toFixed(2)} cm`;
}

//Atividade 14
let inputconta = document.querySelector("#conta");
let btRachar = document.querySelector("#btRachar");
let contaTotal = document.querySelector("#contaTotal");

btRachar.onclick = function (){
    let conta = Number(inputconta.value);

    let igualmente = Math.floor(conta/3);

        let Carlos = igualmente;
        let Andre = igualmente;
        let Felipe = conta - (Carlos + Andre);

    contaTotal.innerHTML = `
    Carlos paga: R$ ${Carlos.toFixed(2)} <br>
    André paga: R$ ${Andre.toFixed(2)} <br>
    Felipe paga: R$ ${Felipe.toFixed(2)}
`;
}