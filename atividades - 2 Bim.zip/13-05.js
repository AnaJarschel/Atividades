//Atividade 01
let inputMoney = document.querySelector("#Money");
let btCotação = document.querySelector("#btCotação");
let resultado = document.querySelector("#resultado");

btCotação.onclick = function (){

    //retornando os valores dos inputs em número
    let valor1 = Number(inputMoney.value);

    //Calcular aumentos
    let conversão1 = valor1 * 0.01;
    let Rconversão1 = valor1 + conversão1;

    let conversão2 = valor1 * 0.02;
    let Rconversão2 = valor1 + conversão2;

    let conversão3 = valor1 * 0.05;
    let Rconversão3 = valor1 + conversão3;

    let conversão4 = valor1 * 0.10;
    let Rconversão4 = valor1 + conversão4;

    resultado.innerHTML  = 
    `Valor do Dólar com 1% de aumento = $ ${Rconversão1.toFixed(2)} <br>
    Valor do Dólar com 2% de aumento = $ ${Rconversão2.toFixed(2)} <br>
    Valor do Dólar com 5% de aumento = $ ${Rconversão3.toFixed(2)} <br>
    Valor do Dólar com 10% de aumento = $ ${Rconversão4.toFixed(2)}`;
    //to.Fixed(2) = arredonda o número para duas casas decimais
}

//Atividade 02
let inputQuantasPessoas = document.querySelector("#QuantasPessoas");
let btIngredientes = document.querySelector("#btIngredientes");
let TotalItens = document.querySelector("#TotalItens");

btIngredientes.onclick = function (){
    let iten1 = Number(inputQuantasPessoas.value);

    let ovo = iten1 * 2;
    let queijo = iten1 * 50;
    let farinha = iten1 * 1;

    TotalItens.innerHTML = `Ingredientes para fazer o Omelete: <br><br>
    ${ovo} Ovos <br>
    ${queijo}KG de Queijo <br>
    ${farinha} Colheres de sopa de farinha de trigo <br>
    Sal e pimenta-do-reino moída na hora a gosto`;
}

//Atividade 03
let inputN1 = document.querySelector("#N1");
let inputN2 = document.querySelector("#N2");
let btCalcular = document.querySelector("#btCalcular");
let calculo = document.querySelector("#calculo");

btCalcular.onclick = function (){
    let N1 = Number(inputN1.value);
    let N2 = Number(inputN2.value);

    let somar = N1 + N2;
    let subtrair = N1 - N2;
    let multiplicar = N1 * N2;
    let dividir = N1 / N2;

    calculo.innerHTML = `
    Soma = ${N1} + ${N2} = ${somar} <br>
    Subtração = ${N1} - ${N2} = ${subtrair} <br>
    Multiplicação = ${N1} * ${N2} = ${multiplicar} <br>
    Divisão = ${N1} / ${N2} = ${dividir}`;
}

//Atividade 04
let inputSabor1 = document.querySelector("#Sabor1");
let inputSabor2 = document.querySelector("#Sabor2");
let inputSabor3 = document.querySelector("#Sabor3");
let inputSabor4 = document.querySelector("#Sabor4");
let inputRefri = document.querySelector("#Refri");
let btCarrinho = document.querySelector("#btCarrinho");
let TotalAPagar = document.querySelector("#TotalAPagar");

btCarrinho.onclick = function(){
    let Sabor1 = inputSabor1.value;
    let Sabor2 = inputSabor2.value;
    let Sabor3 = inputSabor3.value;
    let Sabor4 = inputSabor4.value;
    let Refri = Number(inputRefri.value);

    let sabores = 4 * 12; //R$12 por sabor
    let bebida = Refri * 7; //R$7 por refri
    let conta = sabores + bebida;

    TotalAPagar.innerHTML = `
    Sabores Escolhidos: ${Sabor1}, ${Sabor2}, ${Sabor3} e ${Sabor4} <br>
    Pizza = R$ ${sabores.toFixed(2)}; <br>
    + REfrigerante = R$ ${bebida.toFixed(2)}; <br>
    <strong>Total a Pagar = R$ ${conta.toFixed(2)}</strong>`;
}