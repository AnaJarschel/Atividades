let nota1Bim = document.querySelector("#nota1Bim");
let nota2BIm = document.querySelector("#nota2Bim");
let btAprovação = document.querySelector("#btAprovação");
let Resultado = document.querySelector("#Resultado");

function calcularMedia (){
    
    //retornando os valores dos inputs em números
    let nota1 = Number(nota1Bim.value);
    let nota2 = Number(nota2BIm.value);

    //Calcular a média
    let media = (nota1 + nota2) / 2;

    //Verificar se o aluno está aprovado
    if (media >= 60){
        Resultado.textContent = "Eeeeeee você foi APROVADO!"
    }else{
        Resultado.textContent = "Poxa, você está REPROVADO, vai ter que se esforçar mais."
    }
}
btAprovação.onclick = function(){
    calcularMedia();
}