//Atividade 1 - Triangulos
let inputValorX = document.querySelector("#ValorX");
let inputValorY = document.querySelector("#ValorY");
let inputValorZ = document.querySelector("#ValorZ");
let btInformar = document.querySelector("#btInformar");
let triangulo = document.querySelector("#triangulo");

btInformar.onclick = function () {
    let X = Number (inputValorX.value);
    let Y = Number (inputValorY.value);
    let Z = Number (inputValorZ.value);

    //Verifica se os lados formam um triangulo
    if (X > 0 && X + Y > Z &&
        Y > 0 && Y + Z > X &&
        Z > 0 && Z + X > Y) {

    } else {
    triangulo.textContent = `Os valores informados NÃO FORMAM um triângulo.`;
            
        //Indica o tipo de triângulo
        } if (X === Y && Y === Z) {
        triangulo.textContent = `Forma um triângulo EQUILÁTERO (três lados iguais).`;
    
        } else if (X === Y || X === Z || Y === Z) {
        triangulo.textContent = `Forma um triângulo ISÓSCELES (dois lados iguais).`;
    
        } else {
        triangulo.textContent = `Forma um triângulo ESCALENO (três lados diferentes).`;
       }
};

//Atividade 2 - Calculadora de IMC
let inputAltura = document.querySelector("#Altura");
let inputPeso = document.querySelector("#Peso");
let btCalcularIMC = document.querySelector("#btCalcularIMC");
let classificação = document.querySelector("#classificação");

btCalcularIMC.onclick = function () {
    let altura = Number(inputAltura.value);
    let peso = Number(inputPeso.value);

    //Calculo de imc
    let alturaMetros = altura /100;
    let imc = peso / (alturaMetros * alturaMetros);

    //Verificando e classificando de acordo com o peso
    if (imc < 18.5) 
        {classificação.innerHTML = `${imc.toFixed(2)} Você está abaixo do peso seu ideal, consulte um médico`;}
    
    else if (imc >= 18.5 && imc <= 24.9) 
        {classificação.innerHTML = `${imc.toFixed(2)} Que bom, você está no seu peso ideal cuide-se para manter assim`;}
    
    else if (imc >= 25 && imc <= 29.9) 
        {classificação.innerHTML = `${imc.toFixed(2)} Cuidado, você está com sobrepeso, comece a reavaliar os seus hábitos e procure a ajuda de um médico`;}
    
    else if (imc >= 30 && imc <= 34.9) 
        {classificação.innerHTML = `${imc.toFixed(2)} Sinal de Alerta, você está com Obesidade grau 1, procure um acompanhamento de um médico`;}
    
    else if (imc >= 35 && imc <= 39.9) 
        {classificação.innerHTML = `${imc.toFixed(2)} Atenção, você está com Obesidade grau 2, deve procurar apoio de um médico o qunato antes`;}
    
    else if (imc >= 40) 
        {classificação.innerHTML = `${imc.toFixed(2)} Alerta vermelho, você está com Obesidade grau 3, procure apoio de um médico imediatamente`;}

}

//Atividade 03 - Calculadora de Imposto
let inputMarca = document.querySelector("#Marca");
let inputAno = document.querySelector("#Ano");
let inputValorTabela = document.querySelector("#ValorTabela");
let btImposto = document.querySelector("#btImposto");
let Informações = document.querySelector("#Informações");

btImposto.onclick = function () {
    let Marca = (inputMarca.value);
    let Ano = Number(inputAno.value);
    let Valor = Number(inputValorTabela.value);

    Taxa1 = Valor * 0.01;
    Taxa2 = Valor * 0.015;

    if (Ano < 1990)
        {Informações.innerHTML = `<strong> Total a pagar: R$${Taxa1.toFixed(2)} </strong>`;}

    else if (Ano >= 1990)
        {Informações.innerHTML = `<strong> Total a pagar: R$${Taxa2.toFixed(2)} </strong>`;}
    
}

//Atividade 04 - Calculadora de Salário
let inputCodigo = document.querySelector("#Codigo");
let inputCargo = document.querySelector("#Cargo");
let inputSalario = document.querySelector("#Salario");
let btReajuste = document.querySelector("#btReajuste");
let NovoSalario = document.querySelector("#NovoSalario");

btReajuste.onclick = function () {
    let Codigo = Number(inputCodigo.value);
    let Cargo = (inputCargo.value);
    let Salario = Number(inputSalario.value);

    //Cargo e indices de reajuste
    let Gerente = Salario * 0.10;
    let Engenheiro = Salario * 0.20;
    let Tecnico = Salario * 0.30;
    let NCadastro = Salario * 0.40;

    //Novos Salários
    if (Codigo === 101) {
        reajuste = Salario * 0.10;

    } else if (Codigo === 102) {
        reajuste = Salario * 0.20;

    } else if (Codigo === 103) {
        reajuste = Salario * 0.30;

    } else {
        reajuste = Salario * 0.40;
        Cargo = "não cadastrado";
    }

    let Reajustado = Salario + reajuste;
     
NovoSalario.innerHTML = `Para o cargo de ${Cargo}, o novo Salário Base será R$${Reajustado.toFixed(2)}`;
}

//Atividade 05 - Calculadora de Crédito Bancário
let inputSaldoMedio = document.querySelector("#SaldoMedio");
let btCreditar = document.querySelector("#btCreditar");
let ValorCredito = document.querySelector("#ValorCredito");

btCreditar.onclick = function () {
    let Media = Number(inputSaldoMedio.value);

    if (Media > 0 && Media <= 200)
    {ValorCredito.textContent = `Saldo Insuficiente, não tem direito ao Crédito Especial`;}

    else if (Media >= 201 && Media <= 400) {
    level1 = Media * 0.20;
    ValorCredito.innerHTML = `Valor de Crédito equivalente a 20% <br>
    R$${level1.toFixed(2)}`}

    else if (Media >= 401 && Media <= 600) {
    level2 = Media * 0.30;
    ValorCredito.innerHTML = `Valor de Crédito equivalente a 30% <br>
    R$${level2.toFixed(2)}`;}

    else if (Media >= 601) {
    level3 = Media * 0.40;
    ValorCredito.innerHTML = `Valor de Crédito equivalente a 40%
    R$${level3.toFixed(2)}`;}
}

//Atividade 06 - Lanchonete(Faça o seu pedido)
let inputProduto = document.querySelector("#inputProduto");
let btTotalAPagar = document.querySelector("#btTotalAPagar");
let conta = document.querySelector("#conta");

btTotalAPagar.onclick = function () {
    let Produto = (inputProduto.value);
    let preco;

    if (Produto === "Cachorro Quente") {
        preco = 11.00;}

    else if (Produto === "Bauru") {
        preco = 8.50;}
    
    else if (Produto === "Misto Quente") {
        preco = 8.00;}

    else if (Produto === "Hamburguer") {
        preco = 9.00;}

    else if (Produto === "Chesseburguer") {
        preco = 10.00;}

    else if (Produto === "Refrigerante") {
        preco = 4.50;}
    
    conta.innerHTML = `Total a pagar: R$${preco.toFixed(2)}`;
}

//Atividade 07 - Carrinho de Desconto
let inputEtiqueta = document.querySelector("#Etiqueta");
let inputPagamento = document.querySelector("#inputPagamento");
let btPag = document.querySelector("#btPag");
let Desconto = document.querySelector("#Desconto");

btPag.onclick = function () {
    let Etiqueta = Number(inputEtiqueta.value);
    let Pagamento = (inputPagamento.value);
    let bill;

    if (Pagamento === "A vista em Dinheiro ou Cheque") {
        bill = Etiqueta - (Etiqueta * 0.10);}

    else if (Pagamento === "A vista no Cartão de Crédito") {
        bill = Etiqueta - (Etiqueta * 0.15);}

    else if (Pagamento === "Em 2x sem Juros") {
        bill = Etiqueta;}

    else if (Pagamento === "Em 2x com Juros") {
        bill = Etiqueta + (Etiqueta * 0.10);}

    Desconto.innerHTML = `Total a Pagar: R$${bill.toFixed(2)}`;

}

//Atividade 08 - Sistema de Pagamento
let inputNivel = document.querySelector("#inputNivel");
let inputQuantAula = document.querySelector("#QuantAula");
let btSalario = document.querySelector("#btSalario");
let SalarioHora = document.querySelector("#SalarioHora");

btSalario.onclick = function () {
    let Nivel = (inputNivel.value);
    let QuantAula = Number(inputQuantAula.value);
    let valorHoraAula;
    let sal;

    if (Nivel === "Professor(a) Nível 1") {
        valorHoraAula = 12.00;
        sal = valorHoraAula * QuantAula * 4.5; 
        SalarioHora.innerHTML = `${Nivel}, seu salário será <strong>R$${sal.toFixed(2)}</strong>`;}
    
    else if (Nivel == "Professor(a) Nível 2") {
        valorHoraAula = 17.00;
        sal = valorHoraAula * QuantAula * 4.5;
        SalarioHora.innerHTML = `${Nivel}, seu salário será <strong>R$${sal.toFixed(2)}</strong>`;}
    
    else if (Nivel == "Professor(a) Nível 3") {
        valorHoraAula = 25.00;
        sal = valorHoraAula * QuantAula * 4.5;
        SalarioHora.innerHTML = `${Nivel}, seu salário será <strong>R$${sal.toFixed(2)}</strong>`;}
}

function voltarAoTopo() {
    window.scrollTo({
        top: 50,
        behavior: 'smooth'});
}