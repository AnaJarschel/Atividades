let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let btSomar = document.querySelector("#btSomar");
let resultado = document.querySelector("#resultado");

btSomar.onclick = function () {
    //Convertendo o valores dos input em número
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);

        //calcula a soma e exibe o resultado
        let soma = num1 + num2;
        resultado.textContent = `A soma dos dois números é = ${soma}`;
    }

//Atividade 1
let inputvalorPago = document.querySelector("#valorPago");
let inputprecoProduto = document.querySelector("#precoProduto");
let btTroco = document.querySelector("#btTroco");
let calculoTroco = document.querySelector("#calculoTroco");

btTroco.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let valorPago = parseFloat(inputvalorPago.value);
    let precoProduto = parseFloat(inputprecoProduto.value);

    let troco = valorPago - precoProduto;
    calculoTroco.textContent = `O troco a ser devolvido é = R$ ${troco.toFixed(2)}`;
    //to.Fixed(2) = arredonda o número para duas casas decimais
}


//Atividade 2
let inputvalorQuilo = document.querySelector("#valorQuilo");
let inputquantidade = document.querySelector("#quantidade");
let btAPagar = document.querySelector("#btAPagar");
let precoQuilo = document.querySelector("#precoQuilo");

btAPagar.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let valorQuilo = parseFloat(inputvalorQuilo.value);
    let quantidade = parseFloat(inputquantidade.value);

    let preco = valorQuilo * quantidade;
    precoQuilo.textContent = `O valor a ser pago é = R$ ${preco.toFixed(2)}`;
    //to.Fixed(2) = arredonda o número para duas casas decimais
}


//Atividade 3
let inputsaldo1 = document.querySelector("#saldo1");
let btReajuste = document.querySelector("#btReajuste");
let imprimir = document.querySelector("#imprimir");

btReajuste.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let saldo1= parseFloat(inputsaldo1.value);

    let reajuste = saldo1 * 0.01;
    let saldoComReajuste = saldo1 + reajuste;
    imprimir.textContent = `O saldo com reajuste é de = R$ ${saldoComReajuste.toFixed(2)}`
    //to.Fixed(2) = arredonda o número para duas casas decimais

}


//Atividade 4
let inputnumero1 = document.querySelector("#numero1");
let inputnumero2 = document.querySelector("#numero2");
let inputnumero3 = document.querySelector("#numero3");
let btMedia = document.querySelector("#btMedia");
let calculoMedia = document.querySelector("#calculoMedia");

btMedia.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let numero1 = parseFloat(inputnumero1.value);
    let numero2 = parseFloat(inputnumero2.value);
    let numero3 = parseFloat(inputnumero3.value);

    let aritmetica = (numero1 + numero2 + numero3)/3;
    let ponderada = (numero1 * 3 + numero2 * 2 + numero3 * 5) / (3 + 2 + 5);
    let soma = aritmetica + ponderada;
    let media = soma/2;

    //innerHTML = permite o inserir no texto formatado com HTML, como <br>, <b>, <i>, etc.
    calculoMedia.innerHTML = `
    A média aritmética dos números é: ${aritmetica}; <br>
    A média ponderada dos números é: ${ponderada}; <br>
    A soma das médias é: ${soma}; <br>
    A média das médias é: ${media}`;

}


//Atividade 5
let inputvalor1 = document.querySelector("#valor1");
let inputvalor2 = document.querySelector("#valor2");
let btMaior = document.querySelector("#Maior");
let valorMaior = document.querySelector("#valorMaior");

btMaior.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let valor1 = parseFloat(inputvalor1.value);
    let valor2 = parseFloat(inputvalor2.value);

    //if (se) = Código que será executado se a condição for verdadeira
    if (valor1 > valor2) {
        valorMaior.textContent = `O maior valor é: ${valor1}`;
    
    //else (ou se)= Código que será executado se a condição for falsa
    } else if (valor2 > valor1) {
        valorMaior.textContent = `O maior valor é: ${valor2}`;
   
    } else {
        valorMaior.textContent = `Os valores são iguais.`;
    }
}


//Atividade 6
let inputn1 = document.querySelector("#n1");
let inputn2 = document.querySelector("#n2");
let inputn3 = document.querySelector("#n3");
let inputn4 = document.querySelector("#n4");
let btMenor = document.querySelector("#Menor");
let valorMenor = document.querySelector("#valorMenor");

btMenor.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let n1 = parseFloat(inputn1.value);
    let n2 = parseFloat(inputn2.value);
    let n3 = parseFloat(inputn3.value);
    let n4 = parseFloat(inputn4.value);

    // Encontra o menor valor entre os 4
    let menor = Math.min(n1, n2, n3, n4);

    valorMenor.textContent = `O menor valor é: ${menor}`;

}


//Atividade 7
let inputelemento = document.querySelector("#elemento");
let btImpar = document.querySelector("#Impar");
let valorImpar = document.querySelector("#valorImpar");

btImpar.onclick = function () {
    // parseFloat = converte os valores dos inputs em números
    let elemento = parseFloat(inputelemento.value);
    
    //if (se) = Código que será executado se a condição for verdadeira
    //% 2 !== 0 = é usada para verificar se p número é ímpar (Lê-se: “Se o resto da divisão de XX por 2 for diferente de 0, então o número é ímpar”.)
    if (elemento % 2 !==0) {
        valorImpar.textContent = `O valor informado é impar`;

    }else {
        valorImpar.textContent = `O valor informado não é impar`;
    }

}